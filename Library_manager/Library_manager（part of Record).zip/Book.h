#ifndef BOOK_H
#define BOOK_H
#include "Administrator.h"
#include <string>
class Book{
	std::string BookName;
	int ID;                                                      //6位，前两位代表类型，后四位为具体编号
	std::string WriterName;
	std::string Press;
	std::string PressTime;
	bool Onshelf;
	std::string Position;
	std::string Summary;
	std::string Type;
public:
	int getID();
	std::string getWriterName();
	std::string getPress();
	std::string getPressTime();
	std::string getPosition();
	std::string getSummary();
	std::string getBookName();
	virtual std::string getType() = 0;
	virtual ~Book() {};
};

#endif