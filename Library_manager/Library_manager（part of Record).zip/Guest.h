#ifndef GUEST_H
#define GUEST_H
#include "User.h"
#include "Book.h"
#include "Administrator.h"

class Guest : public User{
	bool In_use;
	const int MaxBook{5};
	int bBook{0};
public:
	static int Num;
	friend class Administrator;
	Guest():bBook(0), MaxBook(3){}
	void set_password(std::string pw);
	void increaseBook();
	void decreaseBook();
	void borrow(Book& book);
	void Return(Book& book);
};

#endif